
<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<body>
<title>One Way Taxi </title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
<body>


  
<ul class="w3-navbar w3-dark-grey">

  <li><a href="index.php">Home</a></li>
  <li><a href="view-offers.php">View Offers</a></li>
  <li><a href="add-ride1.php">Add Ride</a></li>
  <li><a href="balance.php">Balance</a></li>
  <li><a href="add-funds1.php">Add Funds</a></li>
  <li><a href="status.php">Status</a></li>
  <li><a href="logout.php">Logout</a></li>
  <li align = "center"float="left"><?php echo $_SESSION['username'];?></li>
</ul>


<div class="w3-container w3-padding-32">
