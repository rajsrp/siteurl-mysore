</div>
<footer class="w3-footer w3-padding w3-light-grey">
<p>&copy; 2016</p>
</footer>
</body>
</html> 
