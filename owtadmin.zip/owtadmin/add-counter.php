
<?php include 'header.php' ?>
<!-- Header -->
  <header class="w3-container " style="padding-top:22px">
    <h5><b><i class="fa fa-dashboard"></i> Page Title</b></h5>
  </header>



















<?php include 'footer.php' ?>










